#!/bin/bash

icons=($(fd . --type file --extension svg | grep -v "16.*" | grep "folder-.*" | uniq))

dark_aqua="689d6a"
bright_aqua="8ec07c"

dark_green="989719"
bright_green="b7ba25"

dark_red="cb231c"
bright_red="fb4934"

dark_yellow="d69921"
bright_yellow="fabc2f"

dark_blue="458588"
bright_blue="82a598"

dark_purple="b06186"
bright_purple="d2869b"

dark_orange="d55c0d"
bright_orange="fe7f18"

for i in "${!icons[@]}"
do
    item="${icons[$i]}"
    bare=$(echo $item | cut -d'.' -f 1)

    red_icon="$bare-red.svg"
    green_icon="$bare-green.svg"
    yellow_icon="$bare-yellow.svg"
    blue_icon="$bare-blue.svg"
    purple_icon="$bare-purple.svg"
    orange_icon="$bare-orange.svg"

    cp -fv $item $red_icon
    cp -fv $item $green_icon
    cp -fv $item $yellow_icon
    cp -fv $item $blue_icon
    cp -fv $item $purple_icon
    cp -fv $item $orange_icon

    sed -i -e "s/$dark_aqua/$dark_green/g ; s/$bright_aqua/$bright_green/g" $green_icon
    sed -i -e "s/$dark_aqua/$dark_red/g ; s/$bright_aqua/$bright_red/g" $red_icon
    sed -i -e "s/$dark_aqua/$dark_yellow/g ; s/$bright_aqua/$bright_yellow/g" $yellow_icon
    sed -i -e "s/$dark_aqua/$dark_purple/g ; s/$bright_aqua/$bright_purple/g" $purple_icon
    sed -i -e "s/$dark_aqua/$dark_blue/g ; s/$bright_aqua/$bright_blue/g" $blue_icon
    sed -i -e "s/$dark_aqua/$dark_orange/g ; s/$bright_aqua/$bright_orange/g" $orange_icon

done
